addEventListener('DOMContentLoaded', ()=>{
  document.querySelectorAll('.seal').forEach(s=>s.setAttribute('aria-live','polite'));
});
